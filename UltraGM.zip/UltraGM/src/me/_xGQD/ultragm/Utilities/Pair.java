package me._xGQD.ultragm.Utilities;

public class Pair <V1, V2>{
    public V1 value1;
    public V2 value2;
    public Pair(V1 value1, V2 value2){
        this.value1 = value1;
        this.value2 = value2;
    }
}
